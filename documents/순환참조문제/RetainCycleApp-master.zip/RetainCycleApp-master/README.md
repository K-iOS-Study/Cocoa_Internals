# RetainCycleApp

순환 참조 오류에 대한 예제 앱입니다.
This app is an example app contains retain cycle problem in some cases.  

### 사례 case1 - Robot Class
Robot 클래스 내부 reference로 상호 참조

### 사례 case2 - RedViewController  
ViewController와 View 상호 참조

### 사례 case3 - BlueViewController
ViewContoller와 클로저 상호 참조

### 사례 case4 - YelloViewController
ViewController와 DispatchSource 타이머 클로저 상호 참조

